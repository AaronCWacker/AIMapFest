---
title: MN.Map.Hospitals.Top.Five
emoji: 📊
colorFrom: gray
colorTo: blue
sdk: streamlit
sdk_version: 1.17.0
app_file: app.py
pinned: false
license: mit
---

Check out the configuration reference at https://huggingface.co/docs/hub/spaces-config-reference
