---
title: Gradio Maps Latitude Longitude
emoji: 🌖City
colorFrom: red
colorTo: green
sdk: gradio
sdk_version: 3.16.2
app_file: app.py
pinned: false
license: mit
---

Check out the configuration reference at https://huggingface.co/docs/hub/spaces-config-reference
